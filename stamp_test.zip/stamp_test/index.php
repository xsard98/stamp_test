<?php

echo "Program kecil bernama ApaBole";
echo "<br />";
echo "<br />";

$x = 101;

$apabole_array = array();

for($i = 1; $i < $x; $i++){
	if($i % 3 == 0 && $i % 5 == 0){
		$apabole_array[] = "ApaBole";
	}else if($i % 3 == 0){
		$apabole_array[] = "Apa";
	}else if($i % 5 == 0){
		$apabole_array[] = "Bole";
	}else{
		$apabole_array[] = $i;	
	}	
}

echo '<span>'.implode(', ', $apabole_array).'</span>';

echo "<br>";
echo "<br>";
echo "<br>";

echo "Menampilkan ramalan cuaca kota Jakarta untuk 7 hari kedepan";
echo "<br />";
echo "<br />";

$lat = "-6.200000";
$lng = "106.816666";
$key = "492099b896c87f4349396bba7b7f1265";

$api_url = "https://api.openweathermap.org/data/2.5/onecall?lat=".$lat."&lon=".$lng."&appid=".$key;

$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_URL, $api_url);
$result = curl_exec($ch);
curl_close($ch);

$data = json_decode($result);

$daily = $data->daily[0];

for($i = 0; $i < 7; $i++){
	$kelvin = $data->daily[$i]->temp->day;
	$celcius = $kelvin - 273.15;
	
	echo strftime("%a, %d %B %Y:", $data->daily[$i]->dt)." ".$celcius."&#176;C";
	echo "<br>";
}
?>